package vttp2022.assessment.csf.orderbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
