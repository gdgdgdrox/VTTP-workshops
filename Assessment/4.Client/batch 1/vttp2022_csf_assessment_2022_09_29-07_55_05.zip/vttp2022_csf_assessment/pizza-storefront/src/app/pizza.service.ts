// Implement the methods in PizzaService for Task 3
// Add appropriate parameter and return type 

export class PizzaService {

  constructor() { }

  // POST /api/order
  // Add any required parameters or return type
  createOrder(/* add any required parameters */) { 
  }

  // GET /api/order/<email>/all
  // Add any required parameters or return type
  getOrders(/* add any required parameters */) { 
  }

}
